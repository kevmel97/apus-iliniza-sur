/* Apus Iliniza Sur v31.2 — Android OTA self-hosted con bundles firmados.
   Exclusivo para Capacitor nativo. No altera las partidas ni Firebase.
   La firma del ZIP se verifica con la clave PUBLICA incrustada en la configuracion nativa.
*/
(function () {
  'use strict';
  var CONTENT_VERSION = '31.2.1'; // El script de publicacion actualiza esta etiqueta solo en el bundle.
  var OTA_SIGNED_BUILD = true; // La preparación en Mac lo cambia a true al configurar la clave RSA.
  var MANIFEST_URL = 'https://kevmel97.github.io/apus-iliniza-sur/actualizaciones/android/latest.json';
  var ALLOWED_ROOT = 'https://kevmel97.github.io/apus-iliniza-sur/actualizaciones/android/';
  var PENDING_KEY = 'apus_android_ota_pending_v1';
  var LAST_VERSION_KEY = 'apus_android_ota_applied_version_v1';
  var NATIVE_CODE = 2;
  var running = false;

  function setStatus(message) {
    var el = document.getElementById('apus-ota-status');
    if (el) el.textContent = message;
    console.info('[APUS OTA]', message);
  }
  function compareVersions(a,b) {
    var x=String(a).split('.').map(Number), y=String(b).split('.').map(Number);
    for (var i=0;i<3;i++) { if ((x[i]||0)!==(y[i]||0)) return (x[i]||0)>(y[i]||0)?1:-1; }
    return 0;
  }
  function bridge() {
    var cap=window.Capacitor;
    if (!cap || !cap.isNativePlatform || !cap.isNativePlatform()) return null;
    return (cap.Plugins || {}).LiveUpdate || null;
  }
  function validManifest(m, nativeCode) {
    if(!m || m.enabled!==true || m.schema!==1 || m.channel!=='production') return false;
    if(!/^\d+\.\d+\.\d+$/.test(String(m.version||''))) return false;
    if(!/^apus-\d+-\d+-\d+$/.test(String(m.bundleId||''))) return false;
    if(m.bundleId!=='apus-'+m.version.replace(/\./g,'-')) return false;
    if(!Number.isInteger(m.minNativeVersionCode) || m.minNativeVersionCode>nativeCode) return false;
    if(m.maxNativeVersionCode != null && nativeCode>m.maxNativeVersionCode) return false;
    if(typeof m.url!=='string' || !m.url.startsWith(ALLOWED_ROOT)) return false;
    try { var u=new URL(m.url); if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||!u.pathname.endsWith('/'+m.bundleId+'.zip')) return false; } catch(_){return false;}
    if(!/^[a-f\d]{64}$/i.test(String(m.checksum||''))) return false;
    if(typeof m.signature!=='string'||! /^[A-Za-z0-9+/]+={0,2}$/.test(m.signature)||m.signature.length<100) return false;
    return true;
  }
  async function disposeLegacyServiceWorkers() {
    if(!('serviceWorker' in navigator)) return;
    try {
      var regs=await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.filter(function(r){return r.scope.startsWith(location.origin+'/');}).map(function(r){return r.unregister();}));
      if(window.caches){var keys=await caches.keys();await Promise.all(keys.filter(function(x){return x.startsWith('apus-iliniza-sur-');}).map(function(k){return caches.delete(k);}));}
    } catch(e) { console.warn('[APUS OTA] Limpieza de cache antigua:',e); }
  }
  async function fetchManifest() {
    var controller=new AbortController();
    var timeout=setTimeout(function(){controller.abort();},9000);
    try {
      var resp=await fetch(MANIFEST_URL+'?t='+Date.now(),{cache:'no-store',signal:controller.signal,redirect:'error',credentials:'omit'});
      if(!resp.ok) throw new Error('HTTP '+resp.status);
      return await resp.json();
    } finally { clearTimeout(timeout); }
  }
  async function start() {
    var api=bridge();
    if(!api) return;
    if(running) return;
    running=true;
    var ok=!!document.querySelector('#gameCanvas') && !!document.querySelector('#menu-overlay') && typeof window.showOverlay==='function';
    if (!ok) {setStatus('⚠️ Inicio incompleto; se conservará la versión anterior');running=false;return;}
    try {
      var ready=await api.ready(); // DEBE ocurrir antes de descargar o cambiar bundles
      if(ready && ready.rollback) setStatus('⚠️ Se recuperó la versión anterior del juego');
      if(!OTA_SIGNED_BUILD){ setStatus('📦 Contenido '+CONTENT_VERSION+' · Firma OTA pendiente de configurar');return; }
      disposeLegacyServiceWorkers(); // No bloquea la consulta ni el tiempo de rollback
      var nativeInfo=await api.getVersionCode();
      var nativeCode=Number(nativeInfo.versionCode)||NATIVE_CODE;
      var current=await api.getCurrentBundle();
      var currentId=current && current.bundleId;
      var pending=await api.getNextBundle();
      var pendingId=pending && pending.bundleId;
      var localVersion=CONTENT_VERSION;
      var persisted=localStorage.getItem(LAST_VERSION_KEY);
      if(persisted && /^\d+\.\d+\.\d+$/.test(persisted) && compareVersions(persisted,localVersion)>0) localVersion=persisted;
      setStatus('📦 Contenido '+CONTENT_VERSION+' · Actualizaciones automáticas activadas');
      var m=await fetchManifest();
      if(!validManifest(m,nativeCode)) return;
      if(compareVersions(m.version,localVersion)<=0) return;
      if(m.bundleId===currentId || m.bundleId===pendingId) return;
      // Las actualizaciones nuevas son compatibles con la capa nativa instalada.
      if(m.minNativeVersionCode>nativeCode) return;
      var blocked=await api.getBlockedBundles().catch(function(){return {bundleIds:[]};});
      if((blocked.bundleIds||[]).includes(m.bundleId)) {setStatus('⚠️ Se omitió una actualización con errores');return;}
      setStatus('⬇️ Descargando contenido '+m.version+' (puedes seguir jugando)');
      await api.downloadBundle({url:m.url,bundleId:m.bundleId,artifactType:'zip',checksum:m.checksum,signature:m.signature});
      await api.setNextBundle({bundleId:m.bundleId});
      // NO llamamos a reload(): nunca reiniciamos en medio de una partida.
      // getNextBundle se aplica en la próxima apertura en frío del juego.
      try { localStorage.setItem(PENDING_KEY,m.version); } catch (_) {}
      setStatus('✅ Actualización '+m.version+' descargada · Se activará al volver a abrir la app');
    } catch(err) {
      console.warn('[APUS OTA] No se pudo completar la actualización:',err);
      setStatus('📦 Contenido '+CONTENT_VERSION+' · Sin novedades o sin conexión');
    } finally { running=false; }
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
})();
