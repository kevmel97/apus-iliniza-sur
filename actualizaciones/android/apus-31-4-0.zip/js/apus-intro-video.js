/* APUS ILINIZA SUR v31.4.0 — LOGO + VIDEO PREVIO AL SPLASH ORIGINAL.
   El video espera al fin de la comprobación OTA en Android; en la web arranca
   cuando termina de cargar la página. No altera partida, ranking ni Firebase. */
(function () {
  'use strict';
  var opening = document.getElementById('apus-opening');
  if (!opening) return;
  var video = document.getElementById('apus-opening-movie');
  var controls = document.getElementById('apus-opening-controls');
  var helpText = document.getElementById('apus-opening-help-text');
  var replayBtn = document.getElementById('apus-opening-replay');
  var continueBtn = document.getElementById('apus-opening-continue');
  var soundBtn = document.getElementById('apus-opening-sound');
  var active = false, finished = false, videoStarted = false;
  var logoTimer = 0, endTimer = 0, stallTimer = 0;

  function isNative() {
    try { return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()); }
    catch (_) { return false; }
  }
  function resetOriginalSplash() {
    // En 10 s la animación original puede haberse completado detrás del video.
    // Reiniciarla aquí conserva el DOBLE TOQUE original y su animación sin cambios.
    try {
      if (typeof introActive !== 'undefined') introActive = true;
      if (typeof introTimer !== 'undefined') introTimer = 0;
      if (typeof introTapCount !== 'undefined') introTapCount = 0;
      if (typeof introLastTapAt !== 'undefined') introLastTapAt = 0;
      if (typeof exitCinematicActive !== 'undefined') exitCinematicActive = false;
      if (typeof gameState !== 'undefined') gameState = 'INTRO';
      if (typeof showOverlay === 'function') showOverlay(null);
    } catch (e) { console.warn('[APUS INTRO] No se pudo reiniciar la pantalla inicial', e); }
  }
  function finish() {
    if (finished) return;
    finished = true;
    clearTimeout(logoTimer); clearTimeout(endTimer); clearTimeout(stallTimer);
    opening.classList.add('is-closing');
    try { video.pause(); } catch (_) {}
    // Reiniciar el splash cuando se termina la transición, no al inicio del video.
    setTimeout(function () {
      resetOriginalSplash();
      opening.hidden = true;
      opening.remove();
      window.apusOpeningFinished = true;
      document.dispatchEvent(new Event('apus:opening-finished'));
    }, 480);
  }
  function showVideoHelp(message) {
    if (finished || !active) return;
    helpText.textContent = message;
    opening.classList.add('needs-tap');
    controls.setAttribute('aria-hidden','false');
  }
  function tryPlay() {
    clearTimeout(stallTimer);
    opening.classList.remove('needs-tap');
    controls.setAttribute('aria-hidden','true');
    var result;
    try { result = video.play(); }
    catch (error) { showVideoHelp('Toca Reproducir para ver la introducción.'); return; }
    if (result && typeof result.catch === 'function') {
      result.catch(function () {
        showVideoHelp('Android requiere un toque para reproducir el video.');
      });
    }
    stallTimer = setTimeout(function () {
      if (!videoStarted && !finished) showVideoHelp('No se pudo iniciar el video automáticamente.');
    }, 6500);
  }
  function showVideo() {
    if (finished) return;
    opening.classList.remove('is-logo');
    opening.classList.add('is-video');
    video.muted = true; // Autoplay fiable en Android WebView y navegadores.
    tryPlay();
  }
  function start() {
    if (active || finished) return;
    active = true;
    opening.hidden = false;
    opening.classList.add('is-logo');
    opening.setAttribute('aria-hidden','false');
    // Primer cuadro siempre negro hasta que OTA autorice abrir el juego.
    logoTimer = setTimeout(showVideo, 2350);
  }
  function blockGameKeys(e) {
    if (!active || finished) return;
    if (!opening.contains(e.target)) { e.preventDefault(); e.stopImmediatePropagation(); }
  }
  document.addEventListener('keydown', blockGameKeys, true);
  opening.addEventListener('pointerdown', function (e) { e.stopPropagation(); });
  opening.addEventListener('click', function (e) { e.stopPropagation(); });
  video.addEventListener('playing', function () {
    videoStarted = true;
    clearTimeout(stallTimer);
    opening.classList.remove('needs-tap');
    controls.setAttribute('aria-hidden','true');
  });
  video.addEventListener('timeupdate', function () {
    if (Number.isFinite(video.duration) && video.duration - video.currentTime <= 2.55) {
      opening.classList.add('is-finale');
    }
  });
  video.addEventListener('ended', function () {
    endTimer = setTimeout(finish, 800);
  });
  video.addEventListener('error', function () {
    showVideoHelp('No se pudo cargar la introducción. Puedes continuar al inicio normal.');
  });
  replayBtn.addEventListener('click', function () {
    videoStarted = false;
    tryPlay();
  });
  continueBtn.addEventListener('click', finish);
  soundBtn.addEventListener('click', function () {
    video.muted = !video.muted;
    soundBtn.textContent = video.muted ? '🔇 ACTIVAR AUDIO' : '🔊 AUDIO ACTIVADO';
    if (video.paused) tryPlay();
  });

  // El evento lo emite unlockScreen() del actualizador DESPUÉS de comprobar OTA.
  document.addEventListener('apus:ota-ready', start);
  function whenReady() {
    if (isNative()) {
      if (window.apusOTAAllowedToPlay) start();
      // En Android no abrir video durante actualizaciones obligatorias.
    } else start();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', whenReady, {once:true});
  else whenReady();
})();
